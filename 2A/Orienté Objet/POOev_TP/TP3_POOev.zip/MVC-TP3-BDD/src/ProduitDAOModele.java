import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

//DAO pour CRUD (create, read, update, delete)
public class ProduitDAOModele {

	// CRUD: create(obj)
	public int creer(ProduitBeanModele produit) {
		ConnexionBDDModele connexionBDDModele = new ConnexionBDDModele();
		Connection connexion = connexionBDDModele.getConnexion();

		int resultat = -1;
		try {

			String requete = new String("INSERT INTO produit (nom, prix, id_categorie) VALUES (?,?,?);");
			PreparedStatement statement = connexion.prepareStatement(requete, Statement.RETURN_GENERATED_KEYS);

			statement.setString(1, produit.getNom());
			statement.setInt(2, produit.getPrix());
			statement.setInt(3, produit.getCategorie().getId());

			statement.executeUpdate();
			ResultSet rs = statement.getGeneratedKeys();
			if (rs.next()) {
				resultat = rs.getInt(1);
				produit.setId(resultat);
			} else
				resultat = -1;

		} catch (SQLException ex3) {
			while (ex3 != null) {
				System.out.println(ex3.getSQLState());
				System.out.println(ex3.getMessage());
				System.out.println(ex3.getErrorCode());
				ex3 = ex3.getNextException();
			}
		} finally {
			connexionBDDModele.fermerConnexion();
		}
		return resultat;
	}

	// read all
	public List<ProduitBeanModele> lireListe() {
		ConnexionBDDModele connexionBDDModele = new ConnexionBDDModele();
		Connection connexion = connexionBDDModele.getConnexion();

		List<ProduitBeanModele> produitListe = new ArrayList<ProduitBeanModele>();

		try {
			String requete = new String("SELECT id, nom, prix, id_categorie FROM produit;");
			Statement statement = connexion.createStatement();
			ResultSet rs = statement.executeQuery(requete);
			CategorieDAOModele categorieDAOModele = new CategorieDAOModele();
			
			while (rs.next()) {
				ProduitBeanModele produit = new ProduitBeanModele();
				produit.setId(rs.getInt("id"));
				produit.setNom(rs.getString("nom"));
				produit.setPrix(new Integer(rs.getString("prix")));
				produit.setCategorie(categorieDAOModele.lire(rs.getInt("id_categorie")));
				produitListe.add(produit);
			}
		} catch (SQLException ex3) {
			while (ex3 != null) {
				System.out.println(ex3.getSQLState());
				System.out.println(ex3.getMessage());
				System.out.println(ex3.getErrorCode());
				ex3 = ex3.getNextException();
			}
		} finally {
			connexionBDDModele.fermerConnexion();
		}
		return produitListe;
	}
	
	public ProduitBeanModele lire(String id) {
		ConnexionBDDModele connexionBDDModele = new ConnexionBDDModele();
		Connection connexion = connexionBDDModele.getConnexion();
		
		ProduitBeanModele produit = new ProduitBeanModele();
		CategorieDAOModele categorieDAOModele = new CategorieDAOModele();
		
		try {
			String requete = new String("SELECT * FROM produit WHERE id=?;");
			PreparedStatement stmt = connexion.prepareStatement(requete);
			stmt.setString(1, id);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				produit.setCategorie(categorieDAOModele.lire(rs.getInt("id_categorie")));
				produit.setId(rs.getInt("id"));
				produit.setNom(rs.getString("nom"));
				produit.setPrix( new Integer(rs.getString("prix"))); 
			}
			
			
			
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return produit;
		
	}
}